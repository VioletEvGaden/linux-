#########################################################################
# File Name: findBooks.sh
# Author: breezea
# Mail: 1197402377@qq.com
# Created Time: Sun 20 Nov 2022 04:37:51 PM CST
#########################################################################
#!/bin/bash

findBooks(){
		if [ ! -f $bookdb ];then
			echo "The book database is empty."
			return 1
		fi
		error=0
		while :; do
			if [[ $error -eq 0 ]];then
				tput clear
                center 4 "Find books"; boldColor $Brown "Find books"
				tput cup 7 $((Width/2-10)); boldColor $Blue "ID:"
				tput cup 9 $((Width/2-10)); boldColor $Blue "Title:"
				tput cup 11 $((Width/2-10)); boldColor $Blue "Author:"
                tput cup 13 $((Width/2-10)); boldColor $Blue "Tags:"
                tput cup 15 $((Width/2-10)); boldColor $Blue "in/out:"
                tput cup 17 $((Width/2-10)); boldColor $Blue "Borrower:"
				tput cup 7 $((Width/2)); read id
				tput cup 9 $((Width/2)); read title
				tput cup 11 $((Width/2)); read author
				tput cup 13 $((Width/2)); read tags
                tput cup 15 $((Width/2)); read status
                tput cup 17 $((Width/2)); read bname
				message='Are you sure? [y(es)/n(o)/c(ancel)]:'
				inputCol=$(((Width-${#message})/2+${#message}))
				center 24 "$message";color $Cyan "$message"
			fi
			read choice
			case $choice in
			
				y)	printbooks;;
				Y)	printbooks;;
				n)	tput clear;;
				c)	tput clear;return 0;;
				*)	error $((infoHeight+2))	
					tput cp $((infoHeight)) $inputCol
					tput ed;error=0;;
			esac
		done
}
printbooks(){
		tput clear
                awk -v tags=$tags -v id=$id -v title=$title -v author=$author -v status=$status -v bname=$bname 'BEGIN{i=9;FS = "%"}
                $1~id&&$2~title&&$3~author&&$4~tags&&$5~status&&$6~bname{printf "%15s%s\n%15s%s\n%15s%s\n%15s%s\n%15s%s\n\n","ID: ",$1,"Title: ",$2,"Author: ",$3,"Tags: ",$4,"Status: ",$5}' $bookdb

                backmessage="BACK"
				echo
                color $Cyan "$backmessage"
                read result
                case $result in
                        *)      tput clear;return 0;;
				esac

}
