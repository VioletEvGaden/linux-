#########################################################################
# File Name: checkIn.sh
# Author: noya
# Mail: 1066771757@qq.com
# Created Time: Sun 20 Nov 2022 04:38:52 PM CST
#########################################################################
#!/bin/bash

checkIn(){
	tput clear
	any="y"
	while [ "$any" = "y" ];do
		tput clear
		center 4 "Check in books";boldColor $Brown "Check in books"
		centerMessage 7 50;boldColor $Blue "      ID:"
		centerMessage 9 50;boldColor $Blue "   Title:"
		centerMessage 11 50;boldColor $Blue "  Author:"
		centerMessage 13 50;boldColor $Blue "    Tags:"
		centerMessage 15 50;boldColor $Blue "  in/out:"
		centerMessage 17 50;boldColor $Blue "Borrower:"
		centerMessage 19 50;boldColor $Blue " outTime:"
		tput cup 7 $((Width/2-15)); read BookId		
		# 生成bookId
		if [ ${#BookId} -eq 1 ]; then
			BookId="s13-0000$BookId"
		elif [ ${#BookId} -eq 2 ]; then
			BookId="s13-000$BookId"
		elif [ ${#BookId} -eq 3 ]; then
			BookId="s13-00$BookId"
		elif [ ${#BookId} -eq 4 ]; then
			BookId="s13-0$BookId"
		else
			BookId="s13-$BookId"
		fi
		# 检查bookId是否有效
		found_num=`awk -v id=$BookId 'BEGIN{FS="%";count=0}$1==id{count=count+1}END{print count}' books.db` 
		if [[ -z "$found_num" || $found_num -ne 1 ]];then
			errTip="valied BookId! Press any key to retry..."
			center 26 "$errTip"; color $Red "$errTip"
			read -n1 -s key
			continue
		fi
		found_num=`awk -v id=$BookId 'BEGIN{FS="%";count=0}$1~id&&$5~/out/{count=count+1}END{print count}' books.db`
        if [[ -z "$found_num" || $found_num -ne 1 ]];then
              errTip="this book not out! Press any key to retry..."
              center 26 "$errTip"; color $Red "$errTip"
              read -n1 -s key
              continue
        fi
		tput cup 7 $((Width/2-15))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $1}' $bookdb
		tput cup 9 $((Width/2-15))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $2}' $bookdb
		tput cup 11 $((Width/2-15))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $3}' $bookdb
		tput cup 13 $((Width/2-15))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $4}' $bookdb
		tput cup 15 $((Width/2-15))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $5}' $bookdb
		tput cup 17 $((Width/2-15))		
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $6}' $bookdb
		tput cup 19 $((Width/2-15))		
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $7}' $bookdb

		suremessage="Are you sure?[y/n/c]:"
		center 24 "$suremessage";color $Cyan "$suremessage"
		read sure
		case $sure in
			[yY])	sed -i "/^$BookId/s#%out%.*#%in%%#" $bookdb;;
			[nN])	continue;;
			[cC]|*)	tput clear;return 0;;
		esac
		anymessage="Borrow anymore book?[y/n]:"
		center 26 "$anymessage";color $Cyan "$anymessage"
		read any
	done
}

