#########################################################################
# File Name: main.sh
# Author: noya
# Mail: 1066771757@qq.com
# Created Time: Sun 20 Nov 2022 04:32:40 PM CST
#########################################################################
#!/bin/bash
#Personal library managerment System

source enter.sh
source mainMenu.sh
source showBooks.sh
source findBooks.sh
source addBooks.sh
source editorBooks.sh
source checkOut.sh
source checkIn.sh
source deleteBooks.sh

app_name='{0##*[\\/]}'
app_version="1.1"
bookdb=${1:-"books.db"}
User="noya@jxnu.edu.cn"

sysName="Personal Library Managerment System"
sysVersion="Version:$app_version"
sysAuthor="${User}"
sysDate=$(date +%F)

Red=1
Green=2
Brown=3
Blue=4
Purple=5
Cyan=6
White=7
colors=($Red $Green $Grown $blue $Purple $Cyan $White)

Width=$(tput cols)
Height=$(tput lines)

bold=$(tput bold)
rev=$(tput rev)
normal=$(tput sgr0)

center(){
	tput cup $1 $(((Width-${#2})/2))
}
centerMessage(){
	tput cup $1 $(((Width-$2)/2))
}
bold(){
	echo -n ${bold}"$1"${normal}
}

color(){
	echo -ne "\e[3${1}m${2}\e[0m"
}

boldColor(){
	echo -ne "${bold}\e[3${1}m${2}\e[0m"
}

error(){
	errTip='Ivalid Input! Press any key to retry...'
	center 26 "$errTip"; color $Red "$errTip"
	read -n1 -s key
}

showFlash
showMain
