#########################################################################
# File Name: showBooks.sh
# Author: noya
# Mail: 106771757@qq.com
# Created Time: Sun 20 Nov 2022 04:37:36 PM CST
#########################################################################
#!/bin/bash

showBooks(){
	error=0
	while :; do
		if [ $error -eq 0 ];then
			tput clear
			center 6 "Show books"; boldColor $Brown "Show books"
			centerMessage 8 30;  bold "1:Sort by ID"
			centerMessage 10 30; bold "2:Sort by Title"
			centerMessage 12 30; bold "3:Sort by Author"
			centerMessage 14 30; bold "4:Show in"
			centerMessage 16 30; bold "5:Show out"
			centerMessage 18 30; bold "q:Main Menu"
			message='enter your choice(1-3 or q):'
			inputCol=$(((Width-${#message})/2+${#message}))
			center 24 "$message";color $Cyan "$message"
		fi
		read choice
		case $choice in
			1)		showBook 1;;
			2)		showBook 2;;
			3)		showBook 3;;
			4)		showBook 4;;
			5)		showBook 5;;
			[qQ]*)	tput clear;return 0;;
			*)		error $((infoHeight+2))
					tput cup $((infoHeight)) $inputCol
					tput ed;error=0;;
		esac
	done
}
showBook(){
	if [ ! -f $bookdb ];then
		echo "The book database is empty."
		return 1
	fi
	result=y
	until [ "$result" = n ];do
		tput clear
		case $1 in
			1)	sortedById;;
			2)	sortedByTitle;;
			3)	sortedByAuthor;;
			4)	showIn;;
			5)	showOut;;
		esac
		backmessage="back "
		echo
		color $Blue  $backmessage
		read result
		case $result in
			*)	tput clear;return 0;;
		esac
	done

}

sortedById(){

	sort -t"%" -k1 $bookdb| awk 'BEGIN{FS = "%"}
	 {printf "%15s%s\n%15s%s\n%15s%s\n%15s%s\n%15s%s\n","ID: ",$1,"Title: ",$2,"Author: ",$3,"Tags: ",$4,"Status: ",$5}{if ($5=="out"){printf "%15s%s\n%15s%s\n","Bname: ",$6,"OutTime: ",$7}{printf "\n"}}'

}
sortedByTitle(){ 
		 sort -t"%" -k2 $bookdb| awk 'BEGIN{FS = "%"}
			{printf "%15s%s\n%15s%s\n%15s%s\n%15s%s\n%15s%s\n","ID: ",$1,"Title: ",$2,"Author: ",$3,"Tags: ",$4,"Status: ",$5}{if ($5=="out"){printf "%15s%s\n%15s%s\n","Bname: ",$6,"OutTime: ",$7}{printf "\n"}}' 

  }
sortedByAuthor(){
          sort -t"%" -k3 $bookdb| awk 'BEGIN{FS = "%"}
             {printf "%15s%s\n%15s%s\n%15s%s\n%15s%s\n%15s%s\n","ID: ",$1,"Title: ",$2,"Author: ",$3,"Tags: ",$4,"Status: ",$5}{if ($5=="out"){printf "%15s%s\n%15s%s\n","Bname: ",$6,"OutTime: ",$7}{printf "\n"}}'
   }


showIn(){
	awk 'BEGIN{FS = "%"}
	$5~/in/{printf "%15s%s\n%15s%s\n%15s%s\n%15s%s\n%15s%s\n\n","ID: ",$1,"Title: ",$2,"Author: ",$3,"Tags: ",$4,"Status: ",$5}' $bookdb

}
showOut(){
	awk 'BEGIN{FS = "%"}
	$5~/out/{printf "%15s%s\n%15s%s\n%15s%s\n%15s%s\n%15s%s\n\n","ID: ",$1,"Title: ",$2,"Author: ",$3,"Tags: ",$4,"Status: ",$5}' $bookdb      
}
