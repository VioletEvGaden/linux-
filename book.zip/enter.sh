
showFlash(){
	tput clear
	center 10 "$sysName"; boldColor $Brown "$sysName";
	center 12 "$sysVersion"; echo -n "$sysVersion";
	center 14 "$sysAuthor"; color $Green "$sysAuthor";
	center 16 "$sysDate"; echo -n "$sysDate";
	message="Press ENTER to continue..."
	center 20 "$message"; color $Cyan "$message"
	read -n1 key
}


