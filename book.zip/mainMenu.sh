#########################################################################
# File Name: mainMenu.sh
# Author: noya
# Mail: 1066771757@qq.com
# Created Time: Sun 20 Nov 2022 04:37:15 PM CST
#########################################################################
#!/bin/bash

showMain(){
	error=0
	while :; do
		if [[ $error -eq 0 ]];then
			tput clear
			center 4 "Main Menu"; boldColor $Brown "Main Menu";
			centerMessage 7 30;  bold "1: Show books"
			centerMessage 9 30; bold "2: Find books"
			centerMessage 11 30; bold "3: Add books"
			centerMessage 13 30; bold "4: Edit information of books"
			centerMessage 15 30; bold "5: Check out books"
			centerMessage 17 30; bold "6: Check in books"
			centerMessage 19 30; bold "7: Delete books"
			centerMessage 21 30; bold "q: Exit"
			message='Please inter your choice(1-7 or q):'
			inputCol=$(((Width-${#message})/2+${#message}))
			center 24 "$message"; color $Cyan "$message"
		fi
		read choice
		case $choice in
			1)		showBooks;	error=0;;
			2)		findBooks;	error=0;;
			3)		addBooks;	error=0;;
			4)		editBooks;	error=0;;
			5)		checkOut;	error=0;;
			6)		checkIn;	error=0;;
			7)		deleteBooks;error=0;;
#			8)		center 24 "$choice"; color $Cyan "$message";;
			[qQ]*)	tput clear;exit 0;;
			*)		error $((infoHeight+2))
					tput cup $((infoHeight)) $inputCol
					tput ed;	error=0;;
		esac
	done
}

