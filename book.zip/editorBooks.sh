#########################################################################
# File Name: editorBooks.sh
# Author: breezea
# Mail: 1197402377@qq.com
# Created Time: Sun 20 Nov 2022 04:38:22 PM CST
#########################################################################
#!/bin/bash


editBooks(){
	tput clear
	any="y"
	while [ "$any" = "y" ];do
		tput clear
		center 4 "Edit information of books";boldColor $Brown "Edit information of books"
		tput cup 7 $((Width/2-15)) ;boldColor $Blue "BookId:"
		tput cup 9 $((Width/2-15));boldColor $Blue " Title:"
		tput cup 11 $((Width/2-15));boldColor $Blue "Author:"
		tput cup 13 $((Width/2-15));boldColor $Blue "  Tags:"
		tput cup 15 $((Width/2-15));boldColor $Blue "in/out:"
		tput cup 17 $((Width/2-15));boldColor $Blue "Borrower:"
		tput cup 19 $((Width/2-15));boldColor $Blue "outTime:"
		tput cup 7 $((Width/2-5));read BookId

		if [ ${#BookId} -eq 1 ]; then
			BookId="s13-0000$BookId"
		elif [ ${#BookId} -eq 2 ]; then
			BookId="s13-000$BookId"
		elif [ ${#BookId} -eq 3 ]; then
			BookId="s13-00$BookId"
		elif [ ${#BookId} -eq 4 ]; then
			BookId="s13-0$BookId"
		else
			BookId="s13-$BookId"
		fi
		# 检查bookId是否有效
		found_num=`awk -v id=$BookId 'BEGIN{FS="%";count=0}$1==id{count=count+1}END{print count}' books.db` 
		if [[ -z "$found_num" || $found_num -ne 1 ]];then
			errTip="valied BookId! Press any key to retry..."
			center 26 "$errTip"; color $Red "$errTip"
			read -n1 -s key
			continue
		fi

		tput cup 7 $((Width/2-5))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $1}' $bookdb
		tput cup 9 $((Width/2-5))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $2}' $bookdb
		oldTitle=`awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $2}' $bookdb`
		tput cup 11 $((Width/2-5))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $3}' $bookdb
		oldAuthor=`awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $3}' $bookdb`
		tput cup 13 $((Width/2-5))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $4}' $bookdb
		oldTags=`awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $4}' $bookdb`
		tput cup 15 $((Width/2-5))
		awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $5}' $bookdb
		oldState=`awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $5}' $bookdb`
		tput cup 17 $((Width/2-5))
		 awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $6}' $bookdb
         oldBname=`awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $6}' $bookdb`
		 tput cup 19 $((Width/2-5))
          awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $7}' $bookdb
          oldTime=`awk -v BookId=$BookId 'BEGIN{FS="%"}$1~BookId{print $7}' $bookdb`



		tput cup 9 $((Width/2+15)); boldColor $Blue "==>"
		tput cup 11 $((Width/2+15)); boldColor $Blue "==>"
		tput cup 13 $((Width/2+15)); boldColor $Blue "==>"
		tput cup 15 $((Width/2+15)); boldColor $Blue "==>"
		tput cup 17 $((Width/2+15)); boldColor $Blue "==>"
		tput cup 19 $((Width/2+15)); boldColor $Blue "==>" 
		tput cup 9 $((Width/2+20));read Title
		tput cup 11 $((Width/2+20));read Author
		tput cup 13 $((Width/2+20));read Tags
		tput cup 15 $((Width/2+20));read State
		tput cup 17 $((Width/2+20));read bname
		tput cup 19 $((Width/2+20));read Time
		newTitle=${Title:-$oldTitle}
		newAuthor=${Author:-$oldAuthor}
		newTags=${Tags:-$oldTags}
		newState=${State:-$oldState}
		newBname=${bname:-$oldBname}
		newTime=${Time:-$oldTime}
		if [ -z "$oldBname" ];then
			oldBname="shabi"
		fi
		if [ -z "$oldTime" ];then
			oldTime="shabi"
		fi
		suremessage="Are you sure? [y/n/c(ancel)]: "
		center 24 "$suremessage";color $Cyan "$suremessage"
		read sure
		case $sure in
			[yY])	sed -i "/^$BookId/{s@$oldTitle@$newTitle@;s@$oldAuthor@$newAuthor@;s@$oldTags@$newTags@;s@$oldState@$newState@;s@$oldBname@$newBname@;s@$oldTime@$newTime@}" $bookdb;;
			[nN])	continue;;
			[cC]|*)	tput clear;return 0;;
		esac
		anymessage="Edit anymore book?[y(es)/n(o)]:"
		center 26 "$anymessage";color $Cyan "$anymessage"
		read any
	done
}

