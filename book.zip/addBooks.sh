#########################################################################
# File Name: addBooks.sh
# Author: breezea
# Mail: 1197402377@qq.com
# Created Time: Sun 20 Nov 2022 04:38:07 PM CST
#########################################################################
#!/bin/bash

addBooks(){
	tput clear
	any="y"
	while [ "$any" = "y" ];do
		tput clear
		center 4 "Add books";boldColor $Brown "Add books"
		centerMessage 7 50; boldColor $Blue "      ID: "
		centerMessage 9 50; boldColor $Blue "   Title: "
		centerMessage 11 50; boldColor $Blue "  author: "
		centerMessage 13 50; boldColor $Blue "    Tags: "
		tput cup 7 $((Width/2-15)); autoId
		tput cup 9 $((Width/2-15)); read Title
		tput cup 11 $((Width/2-15)); read Author
		tput cup 13 $((Width/2-15)); read Tags
		suremessage="Are you sure? [y/n/c(ancel)]: "
		center 20 "$suremessage";color $Cyan "$suremessage"
		read sure
		BookId=$(autoId)
		case $sure in
			[yY])	echo "$BookId%$Title%$Author%#$Tags%in%%" >>$bookdb;;
			[nN])	continue;;
			[cC]|*)	tput clear;return 0;;
		esac
		anymessage="Success, any book to add?[y/n]:"
		center 22 "$anymessage";color $Cyan "$anymessage"
		read any
	done
}
autoId(){
	new=`awk 'BEGIN{FS="%"}{last=$1}END{print last}' $bookdb | awk 'BEGIN{FS="-"}{print $2+1}'	`
#	new=`awk 'BEGIN{FS="%"}{last=$1}END{print last+1}' $bookdb `
	if [ ${#new} -eq 1 ];then
		new="s13-0000$new"
	elif [ ${#new} -eq 2 ];then
		new="s13-000$new"
	elif [ ${#new} -eq 3 ];then
		new="s13-00$new"
	elif [ ${#new} -eq 4 ];then
		new="s13-0$new"
	else
		new="s13-$new"
	fi
	echo $new
}

